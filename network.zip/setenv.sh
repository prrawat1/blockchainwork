
#!/bin/bash
export IMAGE_TAG="1.4.0"
export COUCH_TAG="1.4.0"
export ZK_TAG="1.4.0"
export KAFKA_TAG="1.4.0"
export TOOLS_TAG="1.2.1"
export TAG_CCENV="1.2.1"
export TAG_BASEOS="0.4.10"


