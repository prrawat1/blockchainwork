
#!/bin/bash
fabric-ca-client enroll  -u https://admin:adminpw@ca.airtel.com:7054 --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.airtel.com-cert.pem 
fabric-ca-client affiliation add airtel  -u https://admin:adminpw@ca.airtel.com:7054 --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.airtel.com-cert.pem 
