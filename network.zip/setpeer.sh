
#!/bin/bash
export ORDERER_CA=/opt/ws/crypto-config/ordererOrganizations/ucc.net/msp/tlscacerts/tlsca.ucc.net-cert.pem

if [ $# -lt 2 ];then
	echo "Usage : . setpeer.sh Airtel|Vodafone| <peerid>"
fi
export peerId=$2

if [[ $1 = "Airtel" ]];then
	echo "Setting to organization Airtel peer "$peerId
	export CORE_PEER_ADDRESS=$peerId.airtel.com:7051
	export CORE_PEER_LOCALMSPID=AirtelMSP
	export CORE_PEER_TLS_CERT_FILE=/opt/ws/crypto-config/peerOrganizations/airtel.com/peers/$peerId.airtel.com/tls/server.crt
	export CORE_PEER_TLS_KEY_FILE=/opt/ws/crypto-config/peerOrganizations/airtel.com/peers/$peerId.airtel.com/tls/server.key
	export CORE_PEER_TLS_ROOTCERT_FILE=/opt/ws/crypto-config/peerOrganizations/airtel.com/peers/$peerId.airtel.com/tls/ca.crt
	export CORE_PEER_MSPCONFIGPATH=/opt/ws/crypto-config/peerOrganizations/airtel.com/users/Admin@airtel.com/msp
fi

if [[ $1 = "Vodafone" ]];then
	echo "Setting to organization Vodafone peer "$peerId
	export CORE_PEER_ADDRESS=$peerId.vodafone.com:7051
	export CORE_PEER_LOCALMSPID=VodafoneMSP
	export CORE_PEER_TLS_CERT_FILE=/opt/ws/crypto-config/peerOrganizations/vodafone.com/peers/$peerId.vodafone.com/tls/server.crt
	export CORE_PEER_TLS_KEY_FILE=/opt/ws/crypto-config/peerOrganizations/vodafone.com/peers/$peerId.vodafone.com/tls/server.key
	export CORE_PEER_TLS_ROOTCERT_FILE=/opt/ws/crypto-config/peerOrganizations/vodafone.com/peers/$peerId.vodafone.com/tls/ca.crt
	export CORE_PEER_MSPCONFIGPATH=/opt/ws/crypto-config/peerOrganizations/vodafone.com/users/Admin@vodafone.com/msp
fi

	