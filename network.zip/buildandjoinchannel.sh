
#!/bin/bash -e




	
	echo "Building channel for preferencechannel" 
	
	. setpeer.sh Airtel peer0
	export CHANNEL_NAME="preferencechannel"
	peer channel create -o orderer.ucc.net:7050 -c $CHANNEL_NAME -f ./preferencechannel.tx --tls true --cafile $ORDERER_CA -t 1000s
	
		
        
            . setpeer.sh Airtel peer0
            export CHANNEL_NAME="preferencechannel"
			peer channel join -b $CHANNEL_NAME.block
		
	
		
        
            . setpeer.sh Vodafone peer0
            export CHANNEL_NAME="preferencechannel"
			peer channel join -b $CHANNEL_NAME.block
		
	
	
	
	
		. setpeer.sh Airtel peer0
		export CHANNEL_NAME="preferencechannel"
		peer channel update -o  orderer.ucc.net:7050 -c $CHANNEL_NAME -f ./preferencechannelAirtelMSPAnchor.tx --tls --cafile $ORDERER_CA 
	

	
	
		. setpeer.sh Vodafone peer0
		export CHANNEL_NAME="preferencechannel"
		peer channel update -o  orderer.ucc.net:7050 -c $CHANNEL_NAME -f ./preferencechannelVodafoneMSPAnchor.tx --tls --cafile $ORDERER_CA 
	




