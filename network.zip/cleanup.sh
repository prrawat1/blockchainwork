
#!/bin/bash
echo "Clearing the old artifacts"
rm *.yaml
rm -rf crypto-config
rm *.block
rm *.tx
rm generateartifacts.sh
rm setenv.sh
rm setpeer.sh
rm buildandjoinchannel.sh
rm *_install.sh
rm *_update.sh
rm add_affi*.sh

