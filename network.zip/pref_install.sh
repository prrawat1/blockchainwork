#!/bin/bash
. setpeer.sh Airtel peer0 
export CHANNEL_NAME="preferencechannel"
peer chaincode install -n pref -v 1.0 -l golang -p  github.com/pref
. setpeer.sh Vodafone peer0 
export CHANNEL_NAME="preferencechannel"
peer chaincode install -n pref -v 1.0 -l golang -p  github.com/pref
peer chaincode instantiate -o orderer.ucc.net:7050 --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA -C preferencechannel -n pref -v 1.0 -c '{"Args":["init",""]}' -P " OR( 'AirtelMSP.member','VodafoneMSP.member' ) " 
